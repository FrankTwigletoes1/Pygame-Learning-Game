import time
import pygame
import random as r


 

#Variabler
screenwidth=1500
screenheight=800
green = (0,255,0)
red = (255,0,0)
lightblue = (0,191,255)
question = True
#x_centered = screenwidth / 2 - imagewidth / 2
#y_centered = screenheight / 2 - imageheight / 2



#Classes
class Background(pygame.sprite.Sprite):
    def __init__(self, image_file, screenwidth, screenheight, location):
        pygame.sprite.Sprite.__init__(self)  #call Sprite initializer
        self.image = pygame.image.load(image_file)
        self.image = pygame.transform.scale(self.image, (screenwidth,screenheight))
        self.rect = self.image.get_rect()
        self.rect.left, self.rect.top = location

BackGround = Background('background.png',screenwidth,screenheight, [0,0])
screen = pygame.display.set_mode((screenwidth,screenheight))
  
        
class button:
    def text_objects(text, font):
        textSurface = font.render(text, True, (0,0,0))
        return textSurface, textSurface.get_rect()

    def btn(msg,x,y,w,h,iColor,aColor, funk=None):
        mousepos = pygame.mouse.get_pos()
        click = pygame.mouse.get_pressed()

        if x+w > mousepos[0] > x and y+h > mousepos[1] > y:
            pygame.draw.rect(screen, aColor,(x,y,w,h))
            if click[0] == 1 and funk != None:
                print("clicked ", click)
                funk()
        else:
            pygame.draw.rect(screen, iColor,(x,y,w,h))

        smallText = pygame.font.SysFont("bitstreamverasans",20)
        textSurf, textRect = button.text_objects(msg, smallText)
        textRect.center = ( (x+(w/2)), (y+(h/2)) )
        screen.blit(textSurf, textRect)

 

class Math:
    def generateQuestion(LowestValue, highestValue):
        global question
        global answer

        num1 = r.randint(LowestValue, highestValue)
        num2 = r.randint(LowestValue, highestValue)
        selector = r.randint(1,3)
        
        if selector == 1:
            print("plus")
            question = ("Hvad er " + str(num1) +  " + " + str(num2))
            answer = num1 + num2

        if selector == 2:
            print("minus")
            question = ("Hvad er " + str(num1) +  " - " + str(num2))
            answer = num1 - num2

        if selector == 3:
            print("gange")
            question = ("Hvad er " + str(num1) +  " * " + str(num2))
            answer = num1 * num2
        print(answer)
        return(answer)
        
            


class Player():
    def __init__(self, x_pos, y_pos, w, h):
        self.x = x_pos
        self.y = y_pos
        self.w = w
        self.h = h
        self.color = (255,0,0)
    
    def move_right(self, steps):
        self.x += 10
        print("right", self.x," ", self.y)

    def move_up(self, steps):
        self.y += 10
        print("up",self.x ," ", self.y)


class triangle:
    def __init__(self, Xspacer_1, Xspacer_2):
        global BackGround
        global screen
        global screenwidth
        global screenheight
        global green
        global red
    
        pygame.draw.polygon(screen, green, (((screenwidth/2)+Xspacer_1,100),((screenwidth/2)+Xspacer_1,500),((screenwidth/2)+Xspacer_2,500)))
        if Xspacer_1 < 0:
            pygame.draw.rect(screen,red,((screenwidth/2+Xspacer_1-40),460, 40, 40))
        else:
            pygame.draw.rect(screen,red,((screenwidth/2+Xspacer_1),460, 40, 40))
